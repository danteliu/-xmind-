//
//  ViewController.m
//  Demo02-Masonry
//
//  Created by tarena on 16/2/5.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ViewController.h"
#import "Masonry.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /*1. 添加红色视图
     步骤：添加到父视图，添加约束
     默认的相对参照物是父视图
     */
    UIView *redView = [UIView new];
    redView.backgroundColor = [UIColor redColor];
    [self.view addSubview:redView];
    //需求：上20;左/右/下:0
    [redView mas_makeConstraints:^(MASConstraintMaker *make) {
        //距离上面
        make.top.mas_equalTo(20);
//        //距离左边
//        make.left.mas_equalTo(0);
//        //距离下面
//        make.bottom.mas_equalTo(0);
//        //距离右边
//        make.right.mas_equalTo(0);
        //上面三行变成一行
        make.left.bottom.right.mas_equalTo(0);
    }];
    
    //添加button;约束:上左:10;宽:100;高:50
    UIButton *greenButton = [UIButton buttonWithType:UIButtonTypeCustom];
    greenButton.backgroundColor = [UIColor greenColor];
    [redView addSubview:greenButton];
    //设置约束
    [greenButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_equalTo(10);
        make.width.mas_equalTo(100);
        make.height.mas_equalTo(50);
    }];
    
    //黑色button;约束:上右:10;宽:100高:50
    UIButton *blackButton = [UIButton buttonWithType:UIButtonTypeCustom];
    blackButton.backgroundColor = [UIColor blackColor];
    [redView addSubview:blackButton];
    /* 负值的设置原则：
       向上移动：负值；
       向左移动：负值
     */
    [blackButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(10);
        make.right.mas_equalTo(-10);
        make.width.mas_equalTo(100);
        make.height.mas_equalTo(50);
    }];
    
    /*自己添加灰色和紫色button
     灰色约束: 左下:10;宽:100;高:50
     紫色约束: 右下:10;宽:100;高:50
     */
    
    /* 需求：使用中心和相对大小设定约束
     添加黄色button; 约束:中心位置等于红色视图的中心；宽和高等于绿色button宽高
     */
    UIButton *yellowButton = [UIButton buttonWithType:UIButtonTypeCustom];
    yellowButton.backgroundColor = [UIColor yellowColor];
    [redView addSubview:yellowButton];
    [yellowButton mas_makeConstraints:^(MASConstraintMaker *make) {
        //size指的的宽和高
        make.size.mas_equalTo(greenButton);
        //中心设定
        make.center.mas_equalTo(redView.center);
    }];
    
    /*通过相对参照物的约束设定
     白色button, 宽高和黄色一样；x和黄色button一样; y距离黄色顶部20
     */
    UIButton *whiteButton = [UIButton buttonWithType:UIButtonTypeCustom];
    whiteButton.backgroundColor = [UIColor whiteColor];
    [redView addSubview:whiteButton];
    [whiteButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(yellowButton);
        make.centerX.mas_equalTo(yellowButton.center);
        make.bottom.mas_equalTo(yellowButton.mas_top).mas_equalTo(-20);
    }];
    
    /*倍数的设定2倍;1/2倍
     需求:蓝色button，宽是白色按钮的2倍数;高是白色按钮0.5倍；x和白色一样；y距离白色上白20
     */
    UIButton *blueButton = [UIButton buttonWithType:UIButtonTypeCustom];
    blueButton.backgroundColor = [UIColor blueColor];
    [redView addSubview:blueButton];
    [blueButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(whiteButton.mas_width).multipliedBy(2);
        //高为白色一半(乘以0.5;除以2)
        make.height.mas_equalTo(whiteButton.mas_height).dividedBy(2);
        make.centerX.mas_equalTo(whiteButton.center);
        make.bottom.mas_equalTo(whiteButton.mas_top).mas_equalTo(-20);
    }];
    
    
    
    

}



@end
