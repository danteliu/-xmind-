//
//  AbsResponseDataSerializer.m
//  AFNetworking-3.x
//
//  Created by YouXianMing on 16/3/12.
//  Copyright © 2016年 YouXianMing. All rights reserved.
//

#import "AbsResponseDataSerializer.h"

@implementation AbsResponseDataSerializer

- (id)serializeResponseData:(id)data {

    return data;
}

@end
