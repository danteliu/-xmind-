//
//  RequestMethodType.m
//  Networking
//
//  Created by YouXianMing on 15/11/6.
//
//  http://www.cnblogs.com/YouXianMing/
//  https://github.com/YouXianMing
//

#import "RequestMethodType.h"

@implementation RequestMethodType

+ (instancetype)type {

    RequestMethodType *method = [[[self class] alloc] init];
    return method;
}

@end

@implementation GetMethod

@end

@implementation PostMethod

@end