//
//  AbsRequestParameterSerializer.m
//  AFNetworking-3.x
//
//  Created by YouXianMing on 16/3/15.
//  Copyright © 2016年 YouXianMing. All rights reserved.
//

#import "AbsRequestParameterSerializer.h"

@implementation AbsRequestParameterSerializer

- (id)serializeRequestParameter:(id)requestParameter {

    return requestParameter;
}

@end
