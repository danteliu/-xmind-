//
//  ResponseDataType.m
//  Networking
//
//  Created by YouXianMing on 15/11/6.
//
//  http://www.cnblogs.com/YouXianMing/
//  https://github.com/YouXianMing
//

#import "ResponseDataType.h"

@implementation ResponseDataType

+ (instancetype)type {

    ResponseDataType *responseData = [[[self class] alloc] init];
    return responseData;
}

@end

@implementation JsonDataType

@end

@implementation HttpDataType

@end