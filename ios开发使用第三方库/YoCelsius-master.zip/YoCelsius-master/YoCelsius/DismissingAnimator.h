//
//  DismissingAnimator.h
//  MeiBaoShangCheng
//
//  Created by wooboo on 14-6-17.
//  Copyright (c) 2014年 Y.X. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface DismissingAnimator : NSObject <UIViewControllerAnimatedTransitioning>

@end
