//
//  FadeBlackView.h
//  YoCelsius
//
//  Created by XianMingYou on 15/2/28.
//
//  https://github.com/YouXianMing
//  http://www.cnblogs.com/YouXianMing/
//

#import <UIKit/UIKit.h>

@interface FadeBlackView : UIView

- (void)show;
- (void)hide;

@end
