//
//  TemperatureCount.h
//  YoCelsius
//
//  Created by XianMingYou on 15/2/22.
//
//  https://github.com/YouXianMing
//  http://www.cnblogs.com/YouXianMing/
//

#import "NumberCount.h"

@interface TemperatureCount : NumberCount

- (void)startAnimation;

@end
