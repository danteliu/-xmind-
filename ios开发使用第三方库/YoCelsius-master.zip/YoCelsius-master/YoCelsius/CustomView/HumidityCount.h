//
//  HumidityCount.h
//  YoCelsius
//
//  Created by XianMingYou on 15/2/18.
//
//  https://github.com/YouXianMing
//  http://www.cnblogs.com/YouXianMing/
//

#import "NumberCount.h"

@interface HumidityCount : NumberCount

- (void)startAnimation;

@end
