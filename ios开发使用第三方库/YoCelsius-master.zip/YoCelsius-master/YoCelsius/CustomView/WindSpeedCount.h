//
//  WindSpeedCount.h
//  YoCelsius
//
//  Created by XianMingYou on 15/2/19.
//
//  https://github.com/YouXianMing
//  http://www.cnblogs.com/YouXianMing/
//

#import "NumberCount.h"

@interface WindSpeedCount : NumberCount

- (void)startAnimation;

@end
