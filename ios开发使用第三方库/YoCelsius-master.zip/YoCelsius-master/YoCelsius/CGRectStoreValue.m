//
//  CGRectStoreValue.m
//  YoCelsius
//
//  Created by YouXianMing on 15/12/17.
//  Copyright © 2015年 XianMingYou. All rights reserved.
//

#import "CGRectStoreValue.h"

@implementation CGRectStoreValue

@end
