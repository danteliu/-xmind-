//
//  PresentingAnimator.h
//
//  Copyright (c) 2014年 Y.X. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface PresentingAnimator : NSObject<UIViewControllerAnimatedTransitioning>

@end