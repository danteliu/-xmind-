//
//  SCNavigationBar.h
//
//  Created by Singro on 6/23/14.
//  Copyright (c) 2014 Singro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCNavigationBar : UIView

@end
