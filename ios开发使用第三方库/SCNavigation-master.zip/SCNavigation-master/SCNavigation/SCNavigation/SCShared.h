//
//  SCShared.h
//
//  Created by Singro on 5/19/15.
//  Copyright (c) 2014 Singro. All rights reserved.
//


#import "FrameAccessor.h"

#define kNavigationBarTintColor [UIColor blackColor]
#define kNavigationBarColor     [UIColor colorWithWhite:1.00 alpha:0.980]
#define kNavigationBarLineColor [UIColor colorWithWhite:0.869 alpha:1]
