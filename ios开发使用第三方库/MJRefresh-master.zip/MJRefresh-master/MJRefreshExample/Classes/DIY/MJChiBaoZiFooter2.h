//
//  MJChiBaoZiFooter2.h
//  MJRefreshExample
//
//  Created by MJ Lee on 15/6/12.
//  Copyright © 2015年 小码哥. All rights reserved.
//

#import "MJRefreshBackGifFooter.h"

@interface MJChiBaoZiFooter2 : MJRefreshBackGifFooter

@end
