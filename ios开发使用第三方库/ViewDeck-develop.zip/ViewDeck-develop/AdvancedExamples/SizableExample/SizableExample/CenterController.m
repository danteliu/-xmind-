//
//  CenterController.m
//  SizableExample
//
//  Created by Tom Adriaenssen on 14/01/12.
//  Copyright (c) 2012 Adriaenssen BVBA. All rights reserved.
//

#import "CenterController.h"

@implementation CenterController

@end
