//
//  SideViewController.h
//  FoursExample
//
//  Created by Tom Adriaenssen on 12/09/12.
//  Copyright (c) 2012 Interface Implemenation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SideViewController : UIViewController

@property (nonatomic, strong) UIColor* color;

@end
