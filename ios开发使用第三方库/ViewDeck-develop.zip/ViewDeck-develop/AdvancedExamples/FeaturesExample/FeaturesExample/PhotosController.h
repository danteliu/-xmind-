//
//  PhotosController.h
//  FeaturesExample
//

#import <UIKit/UIKit.h>

@interface PhotosController : UITableViewController

@end
