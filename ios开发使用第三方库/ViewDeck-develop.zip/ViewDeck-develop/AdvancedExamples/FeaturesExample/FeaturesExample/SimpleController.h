//
//  SimpleController.h
//  FeaturesExample
//

#import <UIKit/UIKit.h>

@interface SimpleController : UIViewController

@end
