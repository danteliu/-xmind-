//
//  WebController.h
//  FeaturesExample
//

#import <UIKit/UIKit.h>

@interface WebController : UIViewController

@property (nonatomic, retain) IBOutlet UIWebView* webView;


@end
