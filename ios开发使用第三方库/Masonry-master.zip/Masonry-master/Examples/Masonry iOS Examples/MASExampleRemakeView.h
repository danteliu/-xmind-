//
//  MASExampleRemakeView.h
//  Masonry iOS Examples
//
//  Created by Sam Symons on 2014-06-22.
//  Copyright (c) 2014 Jonas Budelmann. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MASExampleRemakeView : UIView

@end
